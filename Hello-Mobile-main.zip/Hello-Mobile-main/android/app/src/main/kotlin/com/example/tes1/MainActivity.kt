package com.example.tes1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
